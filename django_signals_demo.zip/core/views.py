from django.http import HttpResponse
from .models import TestModel
import threading
import time
from django.db import transaction

def test_sync(request):
    print("\n=== VIEW START ===")
    print("View Thread ID:", threading.get_ident())
    start = time.time()
    TestModel.objects.create(name="Test Sync")
    end = time.time()
    print("Time taken:", end - start)
    print("=== VIEW END ===\n")
    return HttpResponse("Check console logs")

def test_transaction(request):
    try:
        with transaction.atomic():
            TestModel.objects.create(name="Transaction Test")
            print("Before Exception")
            raise Exception("Force rollback")
    except Exception:
        print("Transaction rolled back")

    exists = TestModel.objects.filter(name="Transaction Test").exists()
    print("After rollback exists:", exists)
    return HttpResponse("Check logs")
