from django.urls import path
from .views import test_sync, test_transaction

urlpatterns = [
    path('test/', test_sync),
    path('transaction/', test_transaction),
]
