import time
import threading
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import TestModel

@receiver(post_save, sender=TestModel)
def test_signal(sender, instance, **kwargs):
    print("\n--- SIGNAL START ---")
    print("Signal Thread ID:", threading.get_ident())
    print("Signal sleeping for 3 seconds...")
    time.sleep(3)
    exists = TestModel.objects.filter(id=instance.id).exists()
    print("Inside Signal - Object exists:", exists)
    print("--- SIGNAL END ---\n")
